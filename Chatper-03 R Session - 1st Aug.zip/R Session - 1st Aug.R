

#loop : iterator 

i =1  #init / start from 

while (i<10 ){  #condition 
  
  
  print(i)
  i =i+1  #steps / increment
}

#print in reverse 
i =10
while(i>0){
  print(i)
  i =i-1
}


#WAP to program to show grade
marks = 12

if(marks >=10 && marks<=20){
  
    print('fail')
  
}else if(marks >=21 && marks<=30){
 
    print("fourth") 
}else if(marks >=31 && marks<=40){
  
  print("third") 
  
}else if(marks >=41 && marks<=50){
  
  print("second") 
  
}else{
  
  
  print("first")
}




###vector : collection of data or values 
data <- c(1:10) #will generate range from 1 to 10

d =c(111,2222,44,222,44444)

#vector operation 

d*2 

##
d +100

#
sum(d) #return total 

#avg 
mean(d)  

#max
max(d)

#low 
min(d)

###return value by index
d[1] #return first value
d[3]
d[1:3] #return 1st to 3rd 

###return count of items 
length(d)

##iterate : get count of all even no 
i =1
while (i<=length(d)){
  
  
    if(d[i] %% 2 == 0){
      print(d[i])
    }
  i = i+1
}


##
i=1
s = 0
while(i<=length(d)){
  
  if(d[i] %% 2 >0){
  
        s = s+d[i]
    
  }
  i=i+1
}

print(s)



##row and column merge 
id <- c (1:5)
name <- c("raman","jatin","divya","ayush","mohit")

cbind( id,name) #column bind 
rbind( id,name) #rbind bind 


#dataframe or table 
emp = data.frame(id,name) 


emp

#access the column 
emp$id
emp$name 

#view data in tabular format 
View(emp)


#shwo structure of table
str(emp )


#matrix 
l <- c(1:9)

matrix(l,nrow=3)

matrix(l,nrow=3,byrow = TRUE)




