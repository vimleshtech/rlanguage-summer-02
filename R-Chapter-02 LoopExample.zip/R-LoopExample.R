
#Loop : is iterator or repeation of statement 
#Example : 1 2 3 ... 100 

#init : start from 
#condition 
#increment / steps 

#while loop 

i =1 #start from 
while (i<100){  #condition 
  
  print(i)
  i=i+1         #increment 
}


##print in reverse 
i =10
while(i>0){
  print(i)  
  i =i-1

}


#print table of 2 
i =1
while(i<=10){
  
  print(2*i)
  i=i+1
}

#show sum of all even and odd numebrs  betwen 20 to 100
i =20
se =0
so = 0

while (i<=100){
  
  if(i%%2 ==0){
    se =se+i  
  }else{
      so=so+i
  }
  i =i+1
}

print(se)
print(so)

i=10
while(i>0){
  print(i)
  i=i-1
}


i=51
while(i<=90){
  print(i)
  i=i+1
}


i=1
while(i<=10){
  print(i*3)
  i=i+1
}

#even nos bw 1&50
i=1
while(i<=50){
  if(i%%2 ==0 ){
    print(i)
  }
  i=i+1
}

#sum nd average of all the nos between 10and 20
i=10
s = 0
while(i<=20){
 s = s+i
  i=i+1 
}

print(s)

##
i=10
s=0
while(i<=20){
  
  
    s=s+i
  
  i=i+1
  
}
print(s)
print(s/10)  

#SUM OF ALL NOS BW 10 &20 DIVISIBLE BY 5 AND NOT DIVISIBLE BY 3
i=10
s=0

while(i<=20){
  
  if(i%%5!=0 && i%%3==0 && i%%2==0){
    s = s+i
  }
  
  i=i+1
}

print(s)

##B9.
hs=55
es=33
cs=22
ms=11
ss=67

total = hs+es+cs+ms+ss
avg = total / 5
print(total)
print(avg)


if(avg>60){
  print("A")
}else if(avg>=50){
  print("B")
}else if(avg>=40){
  print("C")
}else{
  print("D")
}
