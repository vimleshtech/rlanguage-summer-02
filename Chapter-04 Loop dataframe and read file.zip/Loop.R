
#print series from 1 to 10
i =1
while (i<=10){
  
  print(i)
  i=i+1
  
}


#print in reverser order 
i =10
while(i>0){
  print(i)
  i =i-1
}


#vector 
v1 = c(1:5)
v2 = c("nitin","jatin","divya","ayush","vidhi")

rbind(v1,v2)

cbind(v1,v2)

#create data frame from vector , every column of data frame is called vector
#
emp = data.frame(v1,v2)

#read data from emp dataframe
emp$v1
emp$v2

#read using index/position
emp[1] #frist column
emp[2] #2nd column


#sum of id
sum(emp[1])

#read row and col/vector by index
emp[1,1] #first row and first col
emp[1,2]
emp[3,1]
emp[3,2]

emp[1:3,1]




#matrix
m =c(1:9)

#convet to matrix from vector
matrix(m,nrow = 3)

matrix(m,nrow = 3,byrow = TRUE)


####
v1 = c(1:5)
v2 = c("nitin","jatin","divya","ayush","vidhi")
gender <- c("male","male","female","male","female")

#convert vector to factor 
as.factor(gender)




#### 
getwd()  #return  current working directory

setwd("C:\\Users\\Tech Vision\\Desktop\\SAS & SQL") #set or change working directory

#read data from file
data = read.table("semi.txt",sep = ";")

data$V1

data$V2
data$V3


View(data) #show data in tabular format 

str(data) #show data type of every vector




## wap to get total salary 
## wap to get count of male an dfemale 


m=c(1000:1100)

matrix(m,nrow=2)
sum(m)
data=read.table("semi.txt",sep=";")

getwd()
data = read.table("semi.txt",sep = ";")

data 

View(data)

sum(data$V4)
i= 1 

g = data$V3
length(g)

i=1
while (i<=length(g)) {
  
  if (g[i]=="male"){
    
    print("M")
    
  }else {
    
    print("other")
  }
  
  
  i= i+1
  
}



