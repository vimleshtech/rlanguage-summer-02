
#reserved words 
letters
LETTERS
month.name


##variables
a = 100
print(a)

b <- 100
print(b)

#assign right to left 200 -> c
200 -> c
print(c)


# addition of number
a =22
b =44
c =a+b
print(C)




##data type 

a =11 #double 
typeof(a)


a ="fhfgyfg"
typeof(a)

a = TRUE  #LOGICAL 
typeof(a)

a = FALSE  #LOGICAL 
typeof(a)



a =c(11,333,4445)  #vector of double
typeof(a)


#check type
a =1
is.numeric(a)



a ="1"
is.numeric(a)


##
a ="1"
b = "2"


#c =a+b #error

as.numeric(a)+as.numeric(b)

#check even or odd number

x =36
x/2   #17.5  #return with decimal  
x%%2   #rem 
x%/%2    #return withou decimal 


if( x%%2 == 0){
  
  print("even no")
  
}else{
  
  print("odd numebr")
}




#Question A2: WAP to input roll number, name and marks of a student in 5 subjects and calculate the total and average marks. Display all the values.marks

#declare the variables and assign the data 
rno <-101
name <-"Nitin Sharma"

hs <-90
ms <- 78
es <- 78
cs <- 67
ss <- 67

#compute 
total <- hs+es+cs+ms+ss
a <- total/5 

#show ouptut 
print(rno)
print(name)
print(total) 
print(a)



#######
# square of a number
x=12
print(x*x)
input a no. & print its cube
x=3
print(x*x*x)
#area and circumference
x=2
print(3.14*x*x)
x=2
print(2*3.14*x)

#area and perimeter
v=2 
b=4
print((v+b)*2)

#if condition

a  <- 4

b <- 4
c <- 5
d  <- 6


if ( (a*a*a ) + (b*b*b) + (c*c*c) == (d*d*d)){
  
  print(" condition is match")
}else{
  print("condition is not match")
}


